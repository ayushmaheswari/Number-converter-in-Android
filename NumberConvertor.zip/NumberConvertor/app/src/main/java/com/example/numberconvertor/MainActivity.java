package com.example.numberconvertor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    TextView textView;

    RadioButton sourceData,destinationData;
    RadioGroup source,destination;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = (EditText)findViewById(R.id.getvalue);
        textView = (TextView)findViewById(R.id.settext);

        source = (RadioGroup)findViewById(R.id.source);
        destination = (RadioGroup)findViewById(R.id.destination);
    }

    public void convert(View view){

        int sourceId = source.getCheckedRadioButtonId();
        sourceData = (RadioButton)findViewById(sourceId);

        int destinationId = destination.getCheckedRadioButtonId();
        destinationData = (RadioButton) findViewById(destinationId);

        try
        {
            if(sourceData.getId()==R.id.sbinary && destinationData.getId()==R.id.dbinary)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 2), 2));
            }
            else if(sourceData.getId()==R.id.sbinary && destinationData.getId()==R.id.doctal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 2), 8));
            }
            else if(sourceData.getId()==R.id.sbinary && destinationData.getId()==R.id.ddecimal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 2), 10));
            }
            else if(sourceData.getId()==R.id.sbinary && destinationData.getId()==R.id.dhexa)
            {

                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 2), 16));
            }



            else if(sourceData.getId()==R.id.soctal && destinationData.getId()==R.id.dbinary)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 8), 2));
            }
            else if(sourceData.getId()==R.id.soctal && destinationData.getId()==R.id.doctal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 8), 8));
            }
            else if(sourceData.getId()==R.id.soctal && destinationData.getId()==R.id.ddecimal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 8), 10));
            }
            else if(sourceData.getId()==R.id.soctal && destinationData.getId()==R.id.dhexa)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 8), 16));
            }




            else if(sourceData.getId()==R.id.sdecimal && destinationData.getId()==R.id.dbinary)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 10), 2));
            }
            else if(sourceData.getId()==R.id.sdecimal && destinationData.getId()==R.id.doctal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 10), 8));
            }
            else if(sourceData.getId()==R.id.sdecimal && destinationData.getId()==R.id.ddecimal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 10), 10));
            }
            else if(sourceData.getId()==R.id.sdecimal && destinationData.getId()==R.id.dhexa)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 10), 16));
            }



            else if(sourceData.getId()==R.id.shexa && destinationData.getId()==R.id.dbinary)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 16), 2));
            }
            else if(sourceData.getId()==R.id.shexa  && destinationData.getId()==R.id.doctal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 16), 8));
            }
            else if(sourceData.getId()==R.id.shexa  && destinationData.getId()==R.id.ddecimal)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 16), 10));
            }
            else if(sourceData.getId()==R.id.shexa  && destinationData.getId()==R.id.dhexa)
            {
                String str = editText.getText().toString();
                textView.setText(Integer.toString(Integer.parseInt(str, 16), 16));
            }

        }
        catch (Exception e)
        {
            Toast.makeText(MainActivity.this,"Error occur", Toast.LENGTH_SHORT).show();
        }

    }
}
